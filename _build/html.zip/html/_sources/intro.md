# Welcome to your Python journey

This is a small document to get you up and running with accessing/using python on University computers (and your own computer should you wish to).

```{tableofcontents}
```
